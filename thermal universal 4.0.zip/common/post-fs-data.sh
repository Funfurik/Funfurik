

MODDIR=${0%/*}

