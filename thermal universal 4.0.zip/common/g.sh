#!/sbin/sh
MODDIR=${0%/*}
C_FILE_PATH="$MODDIR/g"


if [ -f "$C_FILE_PATH" ]; then
    sleep 2
    chmod +x "$C_FILE_PATH"
    "$C_FILE_PATH" &
fi