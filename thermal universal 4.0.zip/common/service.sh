
#!/system/bin/sh
write() {
    local path="$1"
    local data="$2"

    if [ -d "$path" ]; then
        echo "Error: $path is a directory"
        return 1
    fi

    if [ ! -e "$path" ]; then
        echo "Error: $path does not exist"
        return 1
    fi

    if [ -f "$path" ]; then
        # Jika file tidak dapat ditulis
        if [ ! -w "$path" ]; then
            chmod +w "$path" 2>/dev/null || {
                echo "Error: Could not change permissions for $path"
                return 1
            }
        fi

        echo "$data" >"$path" 2>/dev/null || {
            echo "Error: Could not write to $path"
            return 1
        }

        echo "Success: $path → $data"
    fi
}
MODDIR=${0%/*}


while [ "$(getprop sys.boot_completed)" != "1" ]; do
	sleep 10
done



C_FILE_PATH="$MODDIR/system/bin/f"


if [ -f "$C_FILE_PATH" ]; then
    sleep 5
    chmod +x "$C_FILE_PATH"
    "$C_FILE_PATH" &
fi

min_pwrlevel=$(cat /sys/class/kgsl/kgsl-3d0/min_pwrlevel)
echo $min_pwrlevel > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
sleep 5
su -c "sh $MODDIR/conf"

