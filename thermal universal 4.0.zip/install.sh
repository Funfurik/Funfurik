SKIPMOUNT=false

PROPFILE=true

POSTFSDATA=true

LATESTARTSERVICE=true

REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"


REPLACE="
"

print_modname() {
	ui_print "- Magisk version: $MAGISK_VER_CODE"
	ui_print "- Module version: $(grep_prop version "${TMPDIR}/module.prop")"
	if [ "$MAGISK_VER_CODE" -lt 20400 ]; then
		ui_print "*********************************************************"
		ui_print "! 请安装 Magisk v20.4+ (20400+)"
		abort    "*********************************************************"
	fi
}
check_magisk_version
ui_print "*********************************************************"

ui_print""
ui_print " • Device            : $(getprop ro.product.name) | $(getprop ro.product.system.model) | $(getprop ro.product.system.brand) "
sleep 0.3
ui_print " • Version SoC       : $(getprop ro.product.board) "
sleep 0.3
soc=$(getprop ro.soc.model)
#if [ "$(getprop ro.soc.model)" > SM7375 ]; then
  ui_print " • SOC               : $soc, Applying CPU tweak✔️"
sleep 3
#else
#  ui_print " • SOC               : $soc, aborting tweak❌"
#fi
 

ui_print " • Version Android   : $(getprop ro.build.version.release) | SDK: $(getprop ro.build.version.sdk)"
sleep 0.3
ui_print " • Version ABI       : $(getprop ro.product.cpu.abi) "
sleep 0.3
ui_print " • ROM               : $(getprop ro.build.display.id) "
sleep 0.3
ui_print " • KERNEL            : $(uname -r) "
sleep 0.3
ui_print ""
ui_print " • Check thermals"
sleep 0.3
ui_print " • Detected"
sleep 0.3
ui_print " • Kill thermals"
sleep 0.3
ui_print " • Change Temp"
sleep 0.3
SET_TRIP_POINT_TEMP_MAX=200°

ui_print " • Raising temperature limit to a maximum of $SET_TRIP_POINT_TEMP_MAX."



print_modname() {

busybox sleep 0.3
  ui_print "                   "
busybox sleep 0.3
  ui_print " Created By         : @SeniorFurry"
  sleep 0.5
  ui_print " Publisher          : @SeniorFurry"
  sleep 0.5
  ui_print " Credit             : @SeniorFurry "
  sleep 0.5
  ui_print " Thanks for help    : @ossa3ro "
  sleep 1.5
busybox sleep 0.8
  ui_print " Install BusyBox"
  busybox sleep 0.3
  ui_print "      Loading..."
  busybox sleep 0.3
  ui_print "      Installing..."
  ui_print "      Wait.."
  busybox sleep 0.3
  ui_print " Done!!!! "
  busybox sleep 0.8

}





on_install() {

unzip -o "$ZIPFILE" 'system/*' 'apex/*' 'vendor_dlkm/*' -d $MODPATH >&2

while IFS= read -r -d '' file; do

    relpath=${file#$MODPATH}
    

    target_path="$relpath"
    
    filename=$(basename "$file")
    
    if [ ! -f "$target_path" ]; then
    rm -f "$file"
        
    fi
       
done < <(find $MODPATH/system -type f -print0)


find $MODPATH/system -type d -empty -delete

unzip -o "$ZIPFILE" 'common/*' -d $MODPATH >&2

mv $MODPATH/common/* $MODPATH

rmdir $MODPATH/common
mkdir -p "$MODPATH/system/bin"
unzip -o "$ZIPFILE" 'f' -d "$MODPATH/system/bin" >&2
miui=$(getprop ro.miui.ui.version.name)
if [ -n "$miui" ]; then
    ui_print " "
    echo 'persist.sys.miui_animator_sched.bigcores=4-6' >> $MODPATH/system.prop
    echo 'persist.sys.miui_animator_sched.big_prime_cores=4-7' >> $MODPATH/system.prop
    echo 'persist.sys.miui.damon.enable=false' >> $MODPATH/system.prop
else
    ui_print "."
fi

keyvolume(){ 
keyvl=''; keyvl=`getevent -qlc 1 | awk '{print $3}'`
if [ "$keyvl" == "KEY_VOLUMEDOWN" ] || [ "$keyvl" == "ABS_MT_TRACKING_ID" ];then
echo 1
elif [ "$keyvl" == "KEY_VOLUMEUP" ];then
echo 2
elif [ "$keyvl" == "KEY_POWER" ];then
echo 3
else
keyvolume
fi; }


ui_print "! Use volume keys to select"
ui_print "! Press power key for check"
getevent -qlc 1 >&2 && ui_print "  Check OK" || abort "! Check getevent failed"
sleep 1
ui_print " "
ui_print "- Is your kernel >= 5.10?"
ui_print "  Vol+ Yes"
ui_print "  Vol- No"
ui_print " "


if [ "$(keyvolume)" == 2 ]; then
    echo " • All files extracted for your Kernel"
    mkdir -p "/data/adb/service.d/"
    cp -af $MODPATH/g /data/adb/service.d/
    cp -af $MODPATH/g.sh /data/adb/service.d/
    chmod 755 /data/adb/service.d/g.sh
    sleep 1
    ui_print " "
ui_print "- Install Zram?"
ui_print "  Vol+ Zram"
ui_print "  Vol- No Zram"
ui_print " "

sleep 0.5
    if [ "$(keyvolume)" == 2 ]; then
    echo " •Install Zram"
    sed -i '/su -lp 2000 -c/i \
su -c "swapoff /dev/block/zram0\n\
echo "1" > /sys/block/zram0/queue/rq_affinity\n\
echo "1" > /sys/block/zram0/reset\n\
echo "25768329216" > /sys/block/zram0/disksize\n\
echo "22272M" > /sys/block/zram0/mem_limit\n\
echo "zstd" > /sys/block/zram0/compact\n\
echo "zstd" > /sys/block/zram0/comp_algorithm\n\
mkswap /dev/block/zram0\n\
swapon /dev/block/zram0\n\"' $MODPATH/conf
    sleep 0.5
    ui_print " "
    ui_print "- With fake temp battery?"
    ui_print "  Vol+ fake temp battery 🔥"
    ui_print "  Vol- no fake temp battery 🙂"
    ui_print " "
    
    sleep 0.5
        if [ "$(keyvolume)" == 2 ]; then
        echo " • Set fake temp☠️🔥"
        sed -i '/su -lp 2000 -c/i \
su -c "echo 25 > /sys/class/qcom-battery/fake_temp\n\
echo 250 > /sys/class/power_supply/mtk-slv-div-chg/temp\n\
echo 250 > /sys/class/power_supply/mtk-slave-charger/temp\n\
echo 250 > /sys/class/power_supply/battery/temp\n\
echo 250 > /sys/class/power_supply/bms/temp\n\
echo 250 > /sys/class/power_supply/bms/cp_slave/temp\n\
echo 25 > /sys/class/power_supply/bratty/temperature\n\
echo 250 > /sys/class/qcom-battery/connector_temp\n\
"\n\
tempA=25000\n\
for THERMAL_ZONE in /sys/class/thermal/thermal_zone*/type; do\n\
    EMUL_TEMP_FILE="${THERMAL_ZONE%/*}/emul_temp"\n\
    if [ -f "$EMUL_TEMP_FILE" ]; then\n\
    cat $THERMAL_ZONE\n\
        echo "$tempA" > "$EMUL_TEMP_FILE"\n\
    fi\n\
done\n\' $MODPATH/conf
        ui_print " "
        elif [ "$(keyvolume)" == 1 ]; then
        echo " • Without fake temp🙂"
    ui_print " "
     fi
    elif [ "$(keyvolume)" == 1 ]; then
    echo " • Without Zram"
    rm -f $MODPATH/zram
    sleep 0.5
    ui_print " "
    ui_print "- Install fake temp battery?"
    ui_print "  Vol+ fake temp battery 🔥"
    ui_print "  Vol- no fake temp battery 🙂"
    ui_print " "
    
    sleep 0.5
        if [ "$(keyvolume)" == 2 ]; then
        echo " • Set fake temp☠️🔥"
        sed -i '/su -lp 2000 -c/i \
su -c "echo 25 > /sys/class/qcom-battery/fake_temp\n\
echo 250 > /sys/class/power_supply/mtk-slv-div-chg/temp\n\
echo 250 > /sys/class/power_supply/mtk-slave-charger/temp\n\
echo 250 > /sys/class/power_supply/battery/temp\n\
echo 250 > /sys/class/power_supply/bms/temp\n\
echo 250 > /sys/class/power_supply/bms/cp_slave/temp\n\
echo 25 > /sys/class/power_supply/bratty/temperature\n\
echo 250 > /sys/class/qcom-battery/connector_temp\n\
"\n\
tempA=25000\n\
for THERMAL_ZONE in /sys/class/thermal/thermal_zone*/type; do\n\
    EMUL_TEMP_FILE="${THERMAL_ZONE%/*}/emul_temp"\n\
    if [ -f "$EMUL_TEMP_FILE" ]; then\n\
    cat $THERMAL_ZONE\n\
        echo "$tempA" > "$EMUL_TEMP_FILE"\n\
    fi\n\
done\n\' $MODPATH/conf
        ui_print " "
        elif [ "$(keyvolume)" == 1 ]; then
        echo " • Without fake temp🙂"
        ui_print " "
        fi
    fi

elif [ "$(keyvolume)" == 1 ]; then
    rm -f $MODPATH/system/vendor/lib/libthermalclient.so
    rm -f $MODPATH/system/vendor/lib64/libthermalclient.so
    echo " • Some files are not extracted due to your Kernel"
    sleep 0.5
    ui_print " "
ui_print "- Install Zram?"
ui_print "  Vol+ Zram"
ui_print "  Vol- No Zram"
ui_print " "

sleep 0.5
    if [ "$(keyvolume)" == 2 ]; then
    echo " •Install Zram"
sed -i '/su -lp 2000 -c/i \
su -c "swapoff /dev/block/zram0\n\
echo "1" > /sys/block/zram0/queue/rq_affinity\n\
echo "1" > /sys/block/zram0/reset\n\
echo "25768329216" > /sys/block/zram0/disksize\n\
echo "22272M" > /sys/block/zram0/mem_limit\n\
echo "zstd" > /sys/block/zram0/compact\n\
echo "zstd" > /sys/block/zram0/comp_algorithm\n\
mkswap /dev/block/zram0\n\
swapon /dev/block/zram0\n\"' $MODPATH/conf
    sleep 0.5
    ui_print " "
    ui_print "- With fake temp battery?"
    ui_print "  Vol+ fake temp battery 🔥"
    ui_print "  Vol- no fake temp battery 🙂"
    ui_print " "
    
    sleep 0.5
        if [ "$(keyvolume)" == 2 ]; then
        echo " • Set fake temp☠️🔥"
        sed -i '/su -lp 2000 -c/i \
su -c "echo 25 > /sys/class/qcom-battery/fake_temp\n\
echo 250 > /sys/class/power_supply/mtk-slv-div-chg/temp\n\
echo 250 > /sys/class/power_supply/mtk-slave-charger/temp\n\
echo 250 > /sys/class/power_supply/battery/temp\n\
echo 250 > /sys/class/power_supply/bms/temp\n\
echo 250 > /sys/class/power_supply/bms/cp_slave/temp\n\
echo 25 > /sys/class/power_supply/bratty/temperature\n\
echo 250 > /sys/class/qcom-battery/connector_temp\n\
"\n\
tempA=25000\n\
for THERMAL_ZONE in /sys/class/thermal/thermal_zone*/type; do\n\
    EMUL_TEMP_FILE="${THERMAL_ZONE%/*}/emul_temp"\n\
    if [ -f "$EMUL_TEMP_FILE" ]; then\n\
    cat $THERMAL_ZONE\n\
        echo "$tempA" > "$EMUL_TEMP_FILE"\n\
    fi\n\
done\n\' $MODPATH/conf
        ui_print " "
        elif [ "$(keyvolume)" == 1 ]; then
        echo " • Without fake temp🙂"
        ui_print " "
        fi
    elif [ "$(keyvolume)" == 1 ]; then
    echo " • Without Zram"
    
    sleep 0.5
    ui_print " "
    ui_print "- Install fake temp battery?"
    ui_print "  Vol+ fake temp battery 🔥"
    ui_print "  Vol- no fake temp battery 🙂"
    ui_print " "
    
    sleep 0.5
        if [ "$(keyvolume)" == 2 ]; then
        echo " • Set fake temp☠️🔥"
        sed -i '/su -lp 2000 -c/i \
su -c "echo 25 > /sys/class/qcom-battery/fake_temp\n\
echo 250 > /sys/class/power_supply/mtk-slv-div-chg/temp\n\
echo 250 > /sys/class/power_supply/mtk-slave-charger/temp\n\
echo 250 > /sys/class/power_supply/battery/temp\n\
echo 250 > /sys/class/power_supply/bms/temp\n\
echo 250 > /sys/class/power_supply/bms/cp_slave/temp\n\
echo 25 > /sys/class/power_supply/bratty/temperature\n\
echo 250 > /sys/class/qcom-battery/connector_temp"\n\\n\
tempA=25000\n\
for THERMAL_ZONE in /sys/class/thermal/thermal_zone*/type; do\n\
    EMUL_TEMP_FILE="${THERMAL_ZONE%/*}/emul_temp"\n\
    if [ -f "$EMUL_TEMP_FILE" ]; then\n\
    cat $THERMAL_ZONE\n\
        echo "$tempA" > "$EMUL_TEMP_FILE"\n\
    fi\n\
done\n\' $MODPATH/conf
        ui_print " "
        elif [ "$(keyvolume)" == 1 ]; then
        echo " • Without fake temp🙂"
        ui_print " "
        fi
    fi
fi
sleep 2


}


set_permissions() {


  # The following is the default rule, DO NOT remove
set_perm_recursive $MODPATH 0 0 0755 0644
if [ -d $MODPATH/system/vendor ]; then
  set_perm_recursive $MODPATH/system/vendor 0 0 0755 0644 u:object_r:vendor_file:s0
  [ -d $MODPATH/system/vendor/app ] && set_perm_recursive $MODPATH/system/vendor/app 0 0 0755 0644 u:object_r:vendor_app_file:s0
  [ -d $MODPATH/system/vendor/etc ] && set_perm_recursive $MODPATH/system/vendor/etc 0 0 0755 0644 u:object_r:vendor_configs_file:s0
  [ -d $MODPATH/system/vendor/overlay ] && set_perm_recursive $MODPATH/system/vendor/overlay 0 0 0755 0644 u:object_r:vendor_overlay_file:s0
  for FILE in $(find $MODPATH/system/vendor -type f -name *".apk"); do
    [ -f $FILE ] && chcon u:object_r:vendor_app_file:s0 $FILE
  done
fi
  set_perm_recursive $MODPATH 0 0 0755 0644
  
  

  
}

